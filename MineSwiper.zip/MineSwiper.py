import random
from enum import Enum

class GameStatus(Enum):
    WIN='WIN'
    LOST='LOST'
    PLAYING='PLAYNIG'

class Mineswiper():

    def __init__(self):
        self.board=[]
        self.playmoves=[]
        self.gamestatus=GameStatus.PLAYING
        self.row=0
        self.col=0

    def createFeild(self,rows,columns):
        self.row=rows
        self.col=columns
        self.board=[]
        for i in range(rows):
            row=[]
            for i in range(columns):
                row.append('+')
            self.board.append(row)

    def layMine(self,row,column):
        if(self.board[row][column]!='*'):
            self.board[row][column]='*'
            self.AroundMine(row,column)

    def Indexinrange(self,row,col):
        if row<0 or row>=self.row:
            return False
        elif col<0 or col>=self.col:
            return False
        else:
            return True

    def Updatecell(self,row,col):
        if(self.board[row][col]=='+'):
            self.board[row][col]='1'
        elif (self.board[row][col].isnumeric()):
            self.board[row][col]=str(int(self.board[row][col])+1)
    
    def AroundMine(self,row,col):
        #Updateup
        if(self.Indexinrange(row-1,col)):
            self.Updatecell(row-1,col)
        #Updatedown
        if(self.Indexinrange(row+1,col)):
            self.Updatecell(row+1,col)
        #Updateleft
        if(self.Indexinrange(row,col-1)):
            self.Updatecell(row,col-1)
        #Updateright
        if(self.Indexinrange(row,col+1)):
            self.Updatecell(row,col+1)
        #Updateupleft
        if(self.Indexinrange(row-1,col-1)):
            self.Updatecell(row-1,col-1)
        #Updateupright
        if(self.Indexinrange(row-1,col+1)):
            self.Updatecell(row-1,col+1)
        #Updatedownleft
        if(self.Indexinrange(row+1,col-1)):
            self.Updatecell(row+1,col-1)
        #Updatedownright
        if(self.Indexinrange(row+1,col+1)):
            self.Updatecell(row+1,col+1)

    def printField(self):
        for i in range(self.row):
            for j in range(self.col):
                if (i,j) in self.playmoves:
                    print(self.board[i][j],end=" ")
                elif self.gamestatus!=GameStatus.PLAYING and self.board[i][j]=='*':
                    print(self.board[i][j],end=" ")
                else:    
                    print('.', end=" ")
            print()

    def ChangeStatus(self,row,col):
        if self.board[row][col]=='*':
            self.gamestatus=GameStatus.LOST
        else:
            for i in range(self.row):
                for j in range(self.col):
                    if self.board[i][j]!='*' and (i,j) not in self.playmoves:
                        return
            self.gamestatus=GameStatus.WIN  

    def play(self,row,col):
        if self.gamestatus==GameStatus.PLAYING:
            if (row,col) not in self.playmoves and self.board[row][col]!='*':
                self.FloodFill(row,col)
            self.ChangeStatus(row,col) 
            
            
    def status(self):
        return self.gamestatus.value

    def FloodFill(self,row,col):
        if self.Indexinrange(row,col):
            if self.board[row][col]!='*':
                if (row,col) in self.playmoves:
                    return
                self.playmoves.append((row,col))
            if self.board[row][col]!='+':
                return
            #Fillup
            self.FloodFill(row-1,col)
            #Filleft
            self.FloodFill(row,col-1)
            #Filldown
            self.FloodFill(row+1,col)
            #Fillright
            self.FloodFill(row,col+1)


def main():
    game=Mineswiper()
    game.createFeild(10,10)
    for _ in range(20):
        game.layMine(random.randint(0, 9),random.randint(0, 9))
    while(game.status()==GameStatus.PLAYING.value):
        game.printField()
        row=int(input("enter row "))
        col=int(input("enter col "))
        game.play(row,col)
    game.printField()

main()
