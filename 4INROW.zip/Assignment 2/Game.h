#pragma once
#ifndef GAME_H
#define GAME_H
#include "Board.h"
class Game {
	Board* Play;
public:
	Game() :Play(new Board) {}
	Game(int len, int col) :Play(new Board(len, col)) {}
	~Game() { delete Play; };
	void PlayGame();
};




#endif // !GAME_H
