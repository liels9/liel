#include "Game.h"

void Game::PlayGame() {
	int row;
	int col;
	Play->print();
	while (Play->checkgameover()) {
		cout << "Blue Player Turn:" << endl;
		cout << "please enter the column to play 1-"<<Play->getwidth()<< endl;
		cin >> col;
		while ((col <= 0) || (col > Play->getwidth())) {
			cout << "invald move-please enter again" << endl;
			cin >> col;
		}
		row = Play->PlacePlayer(col, blue);
		Play->print();
		if (Play->Winner(row, col, blue)) {
			cout << "Game over!" << endl;
			break;
		}
		cout << "Red Player Turn:" << endl;
		cout << "please enter the column to play 1-" << Play->getwidth()<<endl;
		cin >> col;
		while ((col <= 0) || (col > Play->getwidth())) {
			cout << "invald move-please enter again" << endl;
			cin >> col;
		}
		row = Play->PlacePlayer(col, red);
		Play->print();
		if (Play->Winner(row, col, red)) {
			cout << "Game over!" << endl;
			break;
		}
	}

}
	



