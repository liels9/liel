#include "Game.h"
int main(){
	int length, width;
	cout << endl << "Welcome to 4 in Row Game!!" << endl << "please enter the length " <<
		"and the width of the board:" << endl;
	cin >> length >> width;
	Game Play(length,width);
	Play.PlayGame();

	return 0;
}