#ifndef Game_H
#define _CRT_SECURE_NO_WARNINGS
#define Game_H
enum BoardItems {space=' ',red='R',blue='B'};
#include<iostream>
#include<windows.h>
#include<string>
using namespace std;
class Board {
	int length,width;
	BoardItems **board;
	bool checkdown(int, int, BoardItems);
	bool checksides(int, int, BoardItems);
	bool checkdiagonalleft(int, int, BoardItems);
	bool checkdiagonalright(int, int, BoardItems);
	
public:
	Board();//deafualt ctor;
	Board(int, int); //value ctor
	~Board();
	void print()const;
	int PlacePlayer(int &, BoardItems);
	bool Winner(int, int, BoardItems);
	bool checkgameover();
	int getwidth();
};












#endif // !Game_H

