#include "Board.h"
//default ctor
Board::Board():length(6), width(7) { 
	board = new BoardItems*[length];
	for(int i=0;i<length;i++){
		board[i] = new BoardItems[width];
		for (int j = 0; j < width; j++)
			board[i][j] = space;
	}
}

//value ctor
Board::Board(int length1, int width1) {
	if ((length1 > 6) && (width1 >7))
	{
		width = width1;
		length = length1;
	}
	else
	{
		width = 7;
		length = 6;
	}
	board = new BoardItems*[length];
	for (int i = 0; i < length; i++) {
		board[i] = new BoardItems[width];
		for (int j = 0; j < width; j++)
			board[i][j] = space;
	}
	
}
//dtor
Board:: ~Board() {
	for (int i = 0; i < length; i++)
		delete[] board[i];
	delete board;
}


void Board::print()const {
	char color;
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	cout << endl;
	for (int k = 0; k < width; k++)
		cout << "| " << k + 1<<" ";
	cout <<"|"<< endl;
	for(int i = 0; i < length; i++)
	{
		for (int k = 0; k < width+width+width+width; k++)
			cout << "_";
			cout << endl;
			for (int j = 0; j < width; j++) 
			{
				if (board[i][j] == space)
				{
					color = 254;
					cout << "|";
					SetConsoleTextAttribute(hConsole, 0);
					cout << " " << color << " ";
					SetConsoleTextAttribute(hConsole, 7);
				}
				else if (board[i][j] == red)
				{
					cout << "|";
					SetConsoleTextAttribute(hConsole, 12);
					color = 254;
					cout << " " << color << " ";
					SetConsoleTextAttribute(hConsole, 7);
				}
				else if (board[i][j] == blue)
				{
					cout << "|";
					SetConsoleTextAttribute(hConsole, 9);
					color = 254;
					cout << " " << color << " ";
					SetConsoleTextAttribute(hConsole, 7);
				}
			}
		cout << "|";
		cout << endl;
	}
	for (int k = 0; k < width + width + width+ width; k++)
		cout << "_";
	cout << endl;

}

int Board::PlacePlayer(int &col, BoardItems player) {
	int i=0;
	col--;
	while (board[0][col] != space) {
		cout << "no space-enter another column" << endl;
		cin >> col;
		col--;
	}
	
		while ((i != length)&&(board[i][col] == space)) {
			i++;
		}
		board[i - 1][col] = player;
	return i - 1;
}

//checking winner from down
bool Board::checkdown(int len, int col, BoardItems player) {
	int counter = 0;
	while ((len != length) && (board[len][col] == player)) {
		counter++;
		len++;
	}
	return counter == 4;
}
//checking winner from  sides
bool Board::checksides(int len, int col, BoardItems player) {
	int counter = 0, colleft=col-1,colright=col;
	while (( colright!= width) && (board[len][colright] == player)) {
		counter++;
		colright++;
	}
	while ((colleft != -1) && (board[len][colleft] == player)) {
		counter++;
		colleft--;
	}
	return counter >= 4;

}
//checking winner from left diagonal
bool Board::checkdiagonalleft(int len, int col, BoardItems player) {
	int counter = 0 ,colright=col+1,lenright=len+1;
	while ((len != -1) && (col != -1) && (board[len][col] == player)) {
		counter++;
		col--;
		len--;
	}
	while ((lenright != length) && (colright != width) && (board[lenright][colright] == player)) {
		counter++;
		colright++;
		lenright++;
	}
	return counter >= 4;

}

//checking winner from right diagonal
bool Board::checkdiagonalright(int len, int col, BoardItems player) {
	int counter = 0,lenleft=len+1,colleft=col-1;
	while ((len != -1) && (col != width) && (board[len][col] == player)) {
		counter++;
		col++;
		len--;
	}
	while ((lenleft != length) && (colleft != -1) && (board[lenleft][colleft] == player)) {
		counter++;
		lenleft++;
		colleft--;
	}
	return counter >= 4;
}
bool Board::Winner(int len, int col, BoardItems player) {
	string Name;
	if (player == red)
		Name = "Red";
	else
		Name = "Blue";
	
	if (checkdown(len, col, player)) {
		cout << "The Winner is Player " << Name << endl;
		return true;
	}
	else if (checksides(len, col, player)) {
		cout << "The Winner is Player " << Name << endl;
		return true;
	}
	else if (checkdiagonalleft(len, col, player)) {
		cout << "The Winner is Player " << Name << endl;
		return true;
	}
	else if (checkdiagonalright(len, col, player)) {
		cout << "The Winner is Player " << Name << endl;
		return true;
	}
	else
		return false;
}
bool Board::checkgameover() {
		for (int j = 0; j < width; j++)
			if (board[0][j] == space)
				return true;
	return false;

}
int Board::getwidth() {
	return width;
}