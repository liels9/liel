package StatePattern;

public class Completed implements RacerState {

	@Override
	public String alert() {
		return "Completed";
		// TODO Auto-generated method stub
		
	}

}
